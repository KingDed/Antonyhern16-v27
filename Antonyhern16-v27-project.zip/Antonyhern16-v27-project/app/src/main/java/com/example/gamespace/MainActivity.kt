package com.example.gamespace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.text.InputType
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

val BG = Color.parseColor("#0B0B10")
val CARD = Color.parseColor("#17171F")
val ACCENT = Color.parseColor("#FF2D3F")
val MUTED = Color.parseColor("#9A9AA8")
const val MP = ViewGroup.LayoutParams.MATCH_PARENT
const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

class Drill(val name: String, val mode: Int, val lowerBetter: Boolean, val unit: String, val hint: String)

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private val tabViews = ArrayList<TextView>()
    private var game = "CODM"
    private var fpsToken = 0
    private var fpsLabel: TextView? = null
    private val fmt = SimpleDateFormat("MMM d HH:mm", Locale.getDefault())
    private val fields = listOf("Camera (3rd person)", "Camera (1st person)", "Firing", "ADS red dot", "ADS 2x",
        "ADS 3x", "ADS 4x", "ADS 6x/8x", "Gyroscope", "Gyroscope ADS")
    private val drills = listOf(
        Drill("Reaction time", 0, true, "ms", "5 rounds, tap when the screen turns green."),
        Drill("Target switching", 1, true, "ms", "20 targets, one at a time. Accuracy counted."),
        Drill("Tracking practice", 2, false, "%", "Keep your finger on the moving dot for 15 s."))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL; root.setBackgroundColor(BG)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MP, 0, 1f))
        val bar = LinearLayout(this); bar.setBackgroundColor(CARD)
        listOf("Profiles", "Train", "Matches", "Dash", "Notes").forEachIndexed { i, n ->
            val t = TextView(this); t.text = n; t.gravity = Gravity.CENTER; t.textSize = 13f
            t.setPadding(0, dp(14), 0, dp(14)); t.setOnClickListener { show(i) }
            tabViews.add(t); bar.addView(t, LinearLayout.LayoutParams(0, WC, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(MP, WC))
        setContentView(root)
        show(0)
    }

    override fun onPause() { fpsToken++; super.onPause() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(14).toFloat() }
    private fun tv(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(this); v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        return v
    }
    private fun btn(t: String, onClick: () -> Unit): Button {
        val b = Button(this); b.text = t; b.isAllCaps = false; b.setTextColor(Color.WHITE)
        b.background = round(ACCENT); b.setOnClickListener { onClick() }
        return b
    }
    private fun edit(hint: String, numeric: Boolean): EditText {
        val e = EditText(this); e.hint = hint; e.setTextColor(Color.WHITE); e.setHintTextColor(MUTED)
        if (numeric) e.inputType = InputType.TYPE_CLASS_NUMBER
        return e
    }
    private fun card(vararg v: View): LinearLayout {
        val l = LinearLayout(this); l.orientation = LinearLayout.VERTICAL; l.background = round(CARD)
        l.setPadding(dp(14), dp(12), dp(14), dp(12))
        for (x in v) l.addView(x)
        val lp = LinearLayout.LayoutParams(MP, WC); lp.setMargins(0, 0, 0, dp(10)); l.layoutParams = lp
        return l
    }
    private fun page(title: String): LinearLayout {
        val p = LinearLayout(this); p.orientation = LinearLayout.VERTICAL; p.setPadding(dp(14), dp(40), dp(14), dp(14))
        p.addView(tv(title, 24f, Color.WHITE, true))
        p.addView(tv("REDMAGIC 11 Pro  |  CODM + PUBG", 12f, MUTED))
        p.addView(View(this), LinearLayout.LayoutParams(MP, dp(12)))
        return p
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun toggle(): View {
        val row = LinearLayout(this)
        for (g in listOf("CODM", "PUBG")) {
            val b = Button(this); b.text = g; b.isAllCaps = false; b.setTextColor(Color.WHITE)
            b.background = round(if (g == game) ACCENT else CARD)
            b.setOnClickListener { game = g; show(currentTab) }
            val lp = LinearLayout.LayoutParams(0, WC, 1f); lp.setMargins(0, 0, dp(8), dp(10)); row.addView(b, lp)
        }
        return row
    }

    private var currentTab = 0
    private fun show(i: Int) {
        currentTab = i; fpsToken++; fpsLabel = null
        content.removeAllViews()
        val v: View = try {
            when (i) { 0 -> profilesPage(); 1 -> trainPage(); 2 -> matchesPage(); 3 -> dashPage(); else -> notesPage() }
        } catch (e: Exception) {
            page("Something went wrong").also { it.addView(card(tv("This screen could not load: ${e.message}\nYour saved data is untouched.", 14f, MUTED))) }
        }
        val sv = ScrollView(this); sv.addView(v); content.addView(sv)
        tabViews.forEachIndexed { k, t -> t.setTextColor(if (k == i) ACCENT else MUTED) }
        if (i == 3) startFps()
    }

    // ---------- Profiles ----------
    private fun profilesPage(): View {
        val p = page("Sensitivity Profiles")
        p.addView(toggle())
        val maxV = if (game == "CODM") 100 else 300
        val key = "prof_$game"
        val prof = Store.obj(key)
        for (f in fields) {
            val cur = prof.optInt(f, maxV / 2)
            val label = tv("$f: $cur")
            val sb = SeekBar(this); sb.max = maxV; sb.progress = cur
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, user: Boolean) {
                    label.text = "$f: $v"
                    if (user) Store.putObj(key, Store.obj(key).put(f, v))
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            p.addView(card(label, sb))
        }
        val now = Store.obj(key); val before = Store.obj("snap_$game")
        val cmp = StringBuilder()
        if (before.length() == 0) cmp.append("No 'Before' snapshot yet. Save one, change your sliders, then compare.")
        else for (f in fields) {
            val a = before.optInt(f, maxV / 2); val c = now.optInt(f, maxV / 2)
            cmp.append("$f: $a -> $c  (${if (c - a >= 0) "+" else ""}${c - a})\n")
        }
        p.addView(card(tv("Before / After", 16f, Color.WHITE, true), tv(cmp.toString().trim(), 13f, MUTED),
            btn("Save current as BEFORE") { Store.putObj("snap_$game", Store.obj(key)); show(0) }))
        p.addView(tv("Values are your own notes of in-game settings. Enter the same numbers in the game's settings screen.", 12f, MUTED))
        return p
    }

    // ---------- Training ----------
    private fun trainPage(): View {
        val p = page("Aim Training")
        p.addView(tv("Offline practice targets only. Nothing here touches any game.", 12f, MUTED))
        p.addView(View(this), LinearLayout.LayoutParams(MP, dp(8)))
        for (d in drills) {
            val recs = Store.list("train").filter { it.optString("type") == d.name }
            val scores = recs.map { it.optDouble("score").toFloat() }
            val pb = if (scores.isEmpty()) null else if (d.lowerBetter) scores.min() else scores.max()
            p.addView(card(tv(d.name, 17f, Color.WHITE, true), tv(d.hint, 12f, MUTED),
                tv(if (pb == null) "Personal best: -" else "Personal best: %.1f %s   (%d runs)".format(pb, d.unit, scores.size), 13f),
                ChartView(this, scores.takeLast(20), "Progress (${d.unit}, ${if (d.lowerBetter) "lower" else "higher"} is better)", ACCENT),
                btn("Start") { runDrill(d) }))
        }
        return p
    }

    private fun runDrill(d: Drill) {
        content.removeAllViews()
        val dv = DrillView(this, d.mode) { score, label ->
            val prev = Store.list("train").filter { it.optString("type") == d.name }.map { it.optDouble("score") }
            val isPb = prev.isEmpty() || (if (d.lowerBetter) score < prev.min() else score > prev.max())
            Store.add("train", JSONObject().put("ts", System.currentTimeMillis()).put("type", d.name).put("score", score.toDouble()))
            AlertDialog.Builder(this).setTitle(d.name)
                .setMessage("%.1f %s\n(%s)%s".format(score, d.unit, label, if (isPb) "\n\nNew personal best!" else ""))
                .setPositiveButton("OK") { _, _ -> show(1) }.setCancelable(false).show()
        }
        content.addView(dv, FrameLayout.LayoutParams(MP, MP))
        val q = btn("Quit") { show(1) }
        content.addView(q, FrameLayout.LayoutParams(WC, WC, Gravity.TOP or Gravity.END))
    }

    // ---------- Matches ----------
    private fun matchesPage(): View {
        val p = page("Match History")
        p.addView(toggle())
        val mode = edit("Mode (e.g. Ranked MP, BR Squads)", false)
        val k = edit("Kills", true); val de = edit("Deaths", true); val ping = edit("Ping ms (optional)", true)
        val win = CheckBox(this); win.text = "Win"; win.setTextColor(Color.WHITE)
        p.addView(card(tv("Add match ($game)", 16f, Color.WHITE, true), mode, k, de, ping, win, btn("Save match") {
            val kk = k.text.toString().toIntOrNull(); val dd = de.text.toString().toIntOrNull()
            if (kk == null || dd == null || kk < 0 || dd < 0) { toast("Enter valid numbers for kills and deaths."); return@btn }
            Store.add("match", JSONObject().put("ts", System.currentTimeMillis()).put("game", game)
                .put("mode", mode.text.toString().trim()).put("k", kk).put("d", dd).put("win", win.isChecked)
                .put("ping", ping.text.toString().toIntOrNull() ?: -1))
            toast("Saved"); show(2)
        }))
        val ms = Store.list("match").filter { it.optString("game") == game }
        if (ms.isEmpty()) { p.addView(card(tv("No matches logged for $game yet.", 13f, MUTED))); return p }
        val kd = ms.map { it.optInt("k") / maxOf(it.optInt("d"), 1).toFloat() }
        val wr = ms.count { it.optBoolean("win") } * 100 / ms.size
        p.addView(card(tv("Stats", 16f, Color.WHITE, true),
            tv("Matches: ${ms.size}   Avg K/D: %.2f   Win rate: $wr%%".format(kd.average()), 13f),
            tv("Personal best: ${ms.maxOf { it.optInt("k") }} kills, best K/D %.2f".format(kd.max()), 13f),
            ChartView(this, kd.takeLast(20), "K/D per match", ACCENT),
            ChartView(this, ms.takeLast(20).map { it.optInt("k").toFloat() }, "Kills per match", Color.parseColor("#4DA3FF"))))
        val recent = ms.takeLast(8).reversed().joinToString("\n") {
            "${fmt.format(Date(it.optLong("ts")))}  ${it.optString("mode")}  ${it.optInt("k")}/${it.optInt("d")}  ${if (it.optBoolean("win")) "W" else "L"}"
        }
        p.addView(card(tv("Recent", 16f, Color.WHITE, true), tv(recent, 12f, MUTED)))
        return p
    }

    // ---------- Dashboard ----------
    @Suppress("DEPRECATION")
    private fun dashPage(): View {
        val p = page("Performance Dashboard")
        val d = windowManager.defaultDisplay
        val rates = d.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()
        fpsLabel = tv("Live display rate: measuring...", 14f)
        p.addView(card(tv("Display", 16f, Color.WHITE, true),
            tv("Current refresh rate: ${d.refreshRate.roundToInt()} Hz", 14f),
            tv("Available rates: ${rates.joinToString(" / ")} Hz", 14f), fpsLabel!!))
        val bi: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        p.addView(card(tv("Thermals", 16f, Color.WHITE, true),
            tv(if (t > 0) "Battery temperature: %.1f C".format(t / 10f) else "Temperature unavailable on this device.", 14f),
            tv(if (lvl >= 0) "Battery: $lvl%" else "Battery level unavailable.", 14f),
            tv("Android only shares battery temperature with apps; CPU/GPU temps need Game Space.", 11f, MUTED)))
        val pe = edit("Ping in ms (read it from your game)", true)
        val pings = Store.list("ping")
        p.addView(card(tv("Ping (manual)", 16f, Color.WHITE, true), pe, btn("Record ping") {
            val v = pe.text.toString().toIntOrNull()
            if (v == null || v < 0 || v > 5000) { toast("Enter a ping between 0 and 5000."); return@btn }
            Store.add("ping", JSONObject().put("ts", System.currentTimeMillis()).put("ms", v)); show(3)
        }, ChartView(this, pings.takeLast(20).map { it.optInt("ms").toFloat() }, "Ping history (ms)", Color.parseColor("#4DA3FF"))))
        p.addView(tv("In-match FPS can't be read by normal apps. Use Game Space's built-in overlay for that.", 12f, MUTED))
        return p
    }

    private fun startFps() {
        val token = ++fpsToken
        Choreographer.getInstance().postFrameCallback(object : Choreographer.FrameCallback {
            var first = 0L; var n = 0
            override fun doFrame(t: Long) {
                if (token != fpsToken) return
                if (first == 0L) first = t
                n++
                if (t - first >= 1_000_000_000L) { fpsLabel?.text = "Live display rate: $n fps"; n = 0; first = t }
                Choreographer.getInstance().postFrameCallback(this)
            }
        })
    }

    // ---------- Notes ----------
    private fun notesPage(): View {
        val p = page("Session Notes")
        p.addView(toggle())
        val e = edit("What changed? How did it feel?", false); e.minLines = 3
        p.addView(card(e, btn("Add note ($game)") {
            val s = e.text.toString().trim()
            if (s.isEmpty()) { toast("Write something first."); return@btn }
            Store.add("note", JSONObject().put("ts", System.currentTimeMillis()).put("game", game).put("text", s)); show(4)
        }))
        val notes = Store.list("note")
        if (notes.isEmpty()) p.addView(card(tv("No notes yet.", 13f, MUTED)))
        for (n in notes.reversed()) {
            val c = card(tv("${fmt.format(Date(n.optLong("ts")))}  ${n.optString("game")}", 12f, MUTED), tv(n.optString("text"), 14f))
            c.setOnLongClickListener {
                AlertDialog.Builder(this).setMessage("Delete this note?").setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        val l = Store.list("note"); l.removeAll { it.optLong("ts") == n.optLong("ts") }; Store.save("note", l); show(4)
                    }.show(); true
            }
            p.addView(c)
        }
        return p
    }
}
