package com.example.gamespace

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("antony_store", Context.MODE_PRIVATE) }

    fun list(key: String): MutableList<JSONObject> {
        val out = mutableListOf<JSONObject>()
        try {
            val a = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until a.length()) out.add(a.getJSONObject(i))
        } catch (e: Exception) { /* corrupt data: start clean instead of crashing */ }
        return out
    }
    fun save(key: String, items: List<JSONObject>) {
        val a = JSONArray()
        for (o in items) a.put(o)
        sp.edit().putString(key, a.toString()).apply()
    }
    fun add(key: String, o: JSONObject) { val l = list(key); l.add(o); save(key, l) }
    fun obj(key: String): JSONObject =
        try { JSONObject(sp.getString(key, "{}")) } catch (e: Exception) { JSONObject() }
    fun putObj(key: String, o: JSONObject) { sp.edit().putString(key, o.toString()).apply() }
}
