package com.example.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class ChartView(c: Context, private val vals: List<Float>, private val label: String, private val color: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (resources.displayMetrics.density * 150).toInt())
    }
    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#9A9AA8"); p.textSize = 30f
        c.drawText(label, 8f, 32f, p)
        if (vals.size < 2) { c.drawText("Need 2+ records", 8f, height / 2f, p); return }
        val mn = vals.min(); val mx = vals.max()
        val rng = if (mx - mn < 1e-6f) 1f else mx - mn
        val padL = 12f; val top = 56f; val bot = 16f
        val path = Path()
        val xs = FloatArray(vals.size); val ys = FloatArray(vals.size)
        for (i in vals.indices) {
            xs[i] = padL + i * (width - 2 * padL) / (vals.size - 1)
            ys[i] = top + (1f - (vals[i] - mn) / rng) * (height - top - bot)
            if (i == 0) path.moveTo(xs[i], ys[i]) else path.lineTo(xs[i], ys[i])
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = color
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        for (i in vals.indices) c.drawCircle(xs[i], ys[i], 7f, p)
        p.color = Color.parseColor("#9A9AA8"); p.textSize = 26f
        c.drawText("max %.1f".format(mx), width - 170f, 32f, p)
        c.drawText("min %.1f".format(mn), width - 170f, height - 2f, p)
    }
}

/** Offline practice drills. mode 0 = reaction, 1 = target switching, 2 = tracking. */
class DrillView(c: Context, private val mode: Int, private val done: (Float, String) -> Unit) : View(c) {
    private val rnd = java.util.Random()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tr = 60f
    private var finished = false
    private var started = false
    // reaction
    private var state = 0; private var goAt = 0L; private val times = ArrayList<Float>(); private var msg = "Tap to start.\nWait for GREEN, then tap."
    private val goRun = Runnable { state = 1; goAt = SystemClock.uptimeMillis(); invalidate() }
    // switching / tracking
    private var tx = 0f; private var ty = 0f; private var spawnT = 0L
    private var hits = 0; private var misses = 0; private val hitTimes = ArrayList<Float>()
    private var vx = 0f; private var vy = 0f; private var lastT = 0L; private var lastTurn = 0L
    private var total = 0L; private var onT = 0L; private var touching = false; private var fx = 0f; private var fy = 0f
    private val goal = 20

    override fun onDetachedFromWindow() { removeCallbacks(goRun); super.onDetachedFromWindow() }

    private fun finish(score: Float, label: String) {
        if (finished) return
        finished = true; removeCallbacks(goRun); done(score, label)
    }

    private fun startReaction() {
        started = true; state = 0; msg = "Wait for GREEN..."
        postDelayed(goRun, 1000L + rnd.nextInt(2000))
        invalidate()
    }
    private fun spawn() {
        tx = tr + rnd.nextFloat() * (width - 2 * tr); ty = 140f + tr + rnd.nextFloat() * (height - 2 * tr - 140f)
        spawnT = SystemClock.uptimeMillis()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (finished) return true
        when (mode) {
            0 -> if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                if (!started) startReaction()
                else if (state == 0) { removeCallbacks(goRun); msg = "Too early! Tap to retry."; started = false; invalidate() }
                else {
                    times.add((SystemClock.uptimeMillis() - goAt).toFloat())
                    if (times.size >= 5) finish(times.average().toFloat(), "avg of 5 rounds")
                    else { msg = "${times.last().toInt()} ms\nRound ${times.size}/5 - tap for next"; started = false; state = 0; invalidate() }
                }
            }
            1 -> if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                if (!started) { started = true; spawn(); invalidate() }
                else if (hypot(e.x - tx, e.y - ty) <= tr * 1.2f) {
                    hitTimes.add((SystemClock.uptimeMillis() - spawnT).toFloat()); hits++
                    if (hits >= goal) finish(hitTimes.average().toFloat(), "avg ms/target, $misses misses") else spawn()
                } else misses++
                invalidate()
            }
            2 -> {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { touching = true; if (!started) { started = true; tx = width / 2f; ty = height / 2f; lastT = SystemClock.uptimeMillis(); lastTurn = lastT; invalidate() } }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
                }
                fx = e.x; fy = e.y
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 48f
        when (mode) {
            0 -> {
                c.drawColor(if (state == 1) Color.parseColor("#1DB954") else Color.parseColor("#2A1015"))
                p.color = Color.WHITE
                val lines = (if (state == 1) "TAP NOW" else msg).split("\n")
                lines.forEachIndexed { i, s -> c.drawText(s, width / 2f, height / 2f + i * 64f, p) }
            }
            1 -> {
                c.drawColor(Color.parseColor("#0B0B10")); p.color = Color.WHITE
                c.drawText(if (started) "Hit $hits/$goal   Misses $misses" else "Tap to start. Hit 20 targets fast.", width / 2f, 90f, p)
                if (started) { p.color = Color.parseColor("#FF2D3F"); c.drawCircle(tx, ty, tr, p) }
            }
            else -> {
                c.drawColor(Color.parseColor("#0B0B10")); p.color = Color.WHITE
                if (!started) { c.drawText("Touch to start. Keep your finger on the dot for 15 s.", width / 2f, 90f, p); return }
                val now = SystemClock.uptimeMillis(); val dt = (now - lastT).coerceAtMost(50L); lastT = now; total += dt
                if (touching && hypot(fx - tx, fy - ty) < tr * 1.5f) onT += dt
                if (now - lastTurn > 700) {
                    lastTurn = now; val a = rnd.nextFloat() * 6.283f; val sp = 250f + rnd.nextFloat() * 450f
                    vx = cos(a) * sp; vy = sin(a) * sp
                }
                tx += vx * dt / 1000f; ty += vy * dt / 1000f
                if (tx < tr) { tx = tr; vx = abs(vx) }; if (tx > width - tr) { tx = width - tr; vx = -abs(vx) }
                if (ty < 140f + tr) { ty = 140f + tr; vy = abs(vy) }; if (ty > height - tr) { ty = height - tr; vy = -abs(vy) }
                c.drawText("On target %d%%   %.0f s left".format(if (total > 0) (onT * 100 / total).toInt() else 0, (15000 - total) / 1000f), width / 2f, 90f, p)
                p.color = Color.parseColor("#FF2D3F"); c.drawCircle(tx, ty, tr, p)
                if (touching) { p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = Color.WHITE; c.drawCircle(fx, fy, tr * 1.5f, p) }
                if (total >= 15000) { finish(onT * 100f / total, "% time on target"); return }
                postInvalidateOnAnimation()
            }
        }
    }
}
