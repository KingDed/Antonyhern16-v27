# Antonyhern16-v27
Push this folder to a GitHub repo -> Actions -> "Build APK" -> download artifact `papi19-apk` (contains papi19.apk).
Debug-signed. Uninstall the older com.example.gamespace first (different debug key).
